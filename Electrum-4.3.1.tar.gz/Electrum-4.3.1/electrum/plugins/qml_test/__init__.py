from electrum.i18n import _

fullname = 'QML Plugin Test'
description = '%s\n%s' % (_("Plugin to test QML integration from plugins."), _("Note: Used for development"))
available_for = ['qml']
